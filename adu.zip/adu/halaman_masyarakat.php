<?php
if (isset($_GET['url']))
{
	$url=$_GET['url'];

	switch ($url)
	{
		case 'tulis_pengaduan':
		include 'tulis_pengaduan.php';
		break;
		
		case 'lihat_laporan';
		include 'lihat_laporan.php';
		break;
			# code...
			break;
	}
}
else
{
	?>
	Selamat Datang di Aplikasi Pelaporan Pengaduan Masyarakat<br><br>
	Anda Masuk Sebagai : <h3><b> <?php echo $_SESSION['nama'];
}
?>