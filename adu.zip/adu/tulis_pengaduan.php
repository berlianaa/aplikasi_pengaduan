<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pelaporan!</title>
  <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
       

<div class="card shadow">
<div class="card-header">
    <h3><b>Tulis Pengaduan</b></h3>
    <hr>
</div>
</div>
          

<div class="card-body">
    <form action="simpan_pengaduan.php" method="post" class="form-horizontal" enctype="multipart/form-data">
        <div class="form-group cols-sm-6">
        <label>Tanggal Pengaduan </label>
        <input type="text" name="tgl_pengaduan" value="<?php echo date('Y/m/d'); ?>" class="form-control" readonly>
    </div>

    <div class="form-group cols-sm-6">
        <label>NIK </label>
        <input type="text" name="nik" value="<?php echo $_SESSION['nik']; ?>" class="form-control" readonly>
    </div>

    <div class="form-group cols-sm-6">
        <label>Tulis Pengaduan </label>
        <textarea class="form-control" rows="7" name="isi_laporan"></textarea>
    </div>

    <div class="form-group cols-sm-6">
        <label>Upload Foto </label>
        <input type="file" name="foto" class="form-control" accept=".jpg, .jpeg, .png, .gif"><font color="red"> *tipe yang diupload adalah : .jpg, .jpeg, .png, .gif</font>
    </div>

    <div class="form-group cols-sm-6">
    <input type="submit" value="Simpan" class="btn btn-primary">
    <input type="reset" value="Kosongkan" class="btn btn-warning">
</div>
</form>

</div>

<footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Berliana Anggita Sari-XII RPL</span>
          </div>
        </div>
      </footer>

            </div>

         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
