﻿<?php
session_start();
if (!isset($_SESSION['nama']))
{
  die("Anda Belum Login");
}
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pelaporan!-Masyarakat</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Pelaporan!</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">  <a href="login.html" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                 <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>
                
                    
                    <li class="nav-item">
                    <a class="nav-link" href="masyarakat.php">
                      <i class="fa fa-dashboard fa-3x"></i>
                      <span>Dashboard</span></a>
                  </li>
                    
                      <li class="nav-item">
                    <a class="nav-link" href="?url=tulis_pengaduan">
                       <i class="fa fa-edit fa-3x"></i>
                        <span>Tulis Pengaduan</span></a>
                   </li>
                               
                  <li class="nav-item">
                    <a class="nav-link" href="?url=lihat_laporan">
                      <i class="fa fa-search fa-3x"></i>
                      <span>Lihat Laporan</span></a>
                  </li>  

                  <li class="nav-item">
                  <a class="nav-link" href="logout.php">
                    <i class="fa fa-sign-out fa-3x"></i>
                    <span>Logout</span></a>
                </li> 
                </ul>
               
            </div>
            
        </nav> 
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Aplikasi Pengaduan Masyarakat</h2>   
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />

          <div class="container-fluid">

          <?php include 'halaman_masyarakat.php'; ?>

        </div>

               
    </div>
             <!-- /. PAGE INNER  -->
             <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Berliana Anggita Sari-XII RPL</span>
          </div>
        </div>
      </footer>

            </div>

         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
