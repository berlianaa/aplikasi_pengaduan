﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pelaporan!</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
   
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
     <!-- TABLE STYLES-->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>
<body>
  
        <!-- /. NAV SIDE  -->
        
               
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Data Pengaduan
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Tanggal</th>
                                            <th>NIK</th>
                                            <th>Isi</th>
                                            <th>Foto</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <?php
                                    require 'koneksi.php';
                                    $sql=mysql_query("select * from pengaduan where nik='$_SESSION[nik]'");
                                    while ($data=mysql_fetch_array($sql)) {
                                        # code...
                                    
                                    ?>
                                    <tbody>
                                        <tr class="odd gradeX">
                                            <td><?php echo $data['id_pengaduan']; ?></td>
                                            <td><?php echo $data['tgl_pengaduan']; ?></td>
                                            <td><?php echo $data['nik']; ?></td>
                                            <td><?php echo $data['isi_laporan']; ?></td>
                                            <td><?php echo $data['foto']; ?></td>
                                            <td><?php echo $data['status']; ?></td>
                                            <td>
                                                <!--button-->
                                                <a href="#" class="btn btn-info btn-icon-split">
                                                <span class="icon text-white-50">
                                                <i class="fas fa-info"></i>
                                                </span>
                                                <span class="text">Detail Tanggapan</span>
                                            </a>

                                            <a href="#" class="btn btn-primary btn-icon-split">
                                                <span class="icon text-white-50">
                                                <i class="fas fa-eye"></i>
                                                </span>
                                                <span class="text">Lihat Tanggapan</span>
                                            </a>
                                            </td>
                                        </tr>
                                        
                                    </tbody>
                                    <?php } ?>
                                </table>
                            
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                <!-- /. ROW  -->
           
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
